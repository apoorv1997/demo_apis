var express = require('express');
var router = express.Router();
var db = require('../index');

router.post('/api/users', db.getUsers);

module.exports = router;

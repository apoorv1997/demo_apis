var promise = require('bluebird');

var options = {
    promiseLib: promise
};

var pgp = require('pg-promise')(options);
var db = pgp({
    host:'exp-temp.cvmnfyswawva.ap-south-1.rds.amazonaws.com',
    port:5432,
    database:'perspectAIdev',
    user:'loopdbadmin',
    password:'looptest$'
});
module.exports = {
    getUsers: getUsers
};
